//
//  main.cpp
//  TestCatch
//
//  Created by Hilton Lipschitz on 2014-10-09.
//  Copyright (c) 2014 Hilton Lipschitz. All rights reserved.
//

#include <iostream>

#include "main.h"


int main(int argc, const char * argv[]) {
  // insert code here...
  std::cout << "Hello, World!\n";
  std::cout << Factorial(1) << std::endl;
  std::cout << Factorial(2) << std::endl;
  std::cout << Factorial(6) << std::endl;
  std::cout << Factorial(10) << std::endl;
  
    return 0;
}
